import logging
import logging.handlers
import random

from player import Bot

class hw18581(Bot):

    def onGameRevealed(self, players, spies):
        self.countspy = 2 #the amount of the spies
        self.playerisspy = [] #spies
        self.playerisres = [] #resistances
        self.spies = spies
        self.spyposibility = {} #posibility of a player is a spy in one mission
        self.spyposibility.clear() #clean the dicitionary in every new game
        self.suspicion = {} #value to measure player if or not spy. larger are more prop be spy
        self.suspicion.clear() #celan the dictionary in every new game
        if not self.spy:
            for p in self.others():
                self.spyposibility[p] = 0 #set the value of each player to default 0
            for p in self.others():
                self.suspicion[p] = self.countspy/len(self.others())

    def select(self, players, count):
        playersonmission = []
        teammates = [self]
        if not self.spy: #if I'm not a spy
            teammates.extend(self.playerisres+self.LowSuspicion(count-1)) #choose players from lowsuspicion list
            i = 0
            for p in teammates:
                if p not in playersonmission:
                    playersonmission.append(p)
                    i += 1
                if i == count:
                    break
            return playersonmission
        if self.spy: #if I'm a spy
            return[self] + random.sample(self.others(), count - 1) #choose myself and other random player if I'm a spy

    def vote(self, team):
        self.team = team
        voting = False #myvote
        if self.game.turn == 1:
            voting = True #always agree if it is the first turn
        else:
            if not self.spy:
                if self.game.leader == self:
                    voting = True #if I'm the leader, always vote for myself
                elif team == self.playerisres+[self]:
                    voting = True #if there are resistance in the team, vote agree
                elif self.game.losses == 2:
                    voting = True #if we already lost 2 turns
                for p in team:
                    if p in self.playerisspy:
                        voting = False
                    else:
                        voting = True
        if self.spy:
            if self in team:
                 voting = True #if I'm in the team, always vote for myself
        return voting

    def onVoteComplete(self, votes):
        votedictionary = dict(zip(self.game.players, votes))
        voteplayer = [p for p in self.game.players if votedictionary[p] == True]
        if not self.spy:
            for p in voteplayer:
                if p in self.others():
                    if p not in self.team:
                        if self.game.losses == 2:
                            self.suspicion[p] += 2
                            self.playerisspy.append(p) #consider the player is a spy

    def sabotage(self):
        #if len(self.game.team) = 2:
         #   return False #if there are only two players in a mission,I won't sabotage to expose my identity
        return True

    def onMissionComplete(self, sabotaged):
        for p in self.spyposibility:
            self.suspicion[p] = self.suspicion[p] + self.spyposibility[p]
            if self.spyposibility[p] == 0:
                self.playerisres.append(p)
                self.suspicion[p] = 0
            if self.spyposibility[p] == 1:
                self.playerisspy.append(p)


    def LowSuspicion(self,count):
        lowsus = []
        self.sortedsus = sorted(self.suspicion.items(), key=lambda k: k[1])
        for i in self.sortedsus[0:count]:
            lowsus.append(i[0])
        return lowsus

    def __init__(self, game, index, spy):
        """Constructor called before a game starts.  It's recommended you don't
        override this function and instead use onGameRevealed() to perform
        setup for your AI.
        @param game     the current game state
        @param index    Your own index in the player list.
        @param spy      Are you supposed to play as a spy?
        """
        super(Bot, self).__init__(self.__class__.__name__, index)

        self.game = game
        self.spy = spy

        self.log = logging.getLogger(self.name)
        if not self.log.handlers:
            try:
                output = logging.FileHandler(filename='logs/'+self.name+'.log')
                self.log.addHandler(output)
                self.log.setLevel(logging.DEBUG)
            except IOError:
                pass

    def __repr__(self):
        """Built-in function to support pretty-printing."""
        type = {True: "SPY", False: "RST"}
        return "<%s #%i %s>" % (self.name, self.index, type[self.spy])

